import React from 'react';
import './Toolbar.css';
import DrawerBtn from '../SideDrawer/DrawerBtn';
import logo from './logo.png'

const toolbar = props => (
    <header className="toolbar">
        <nav className="toolbar_navigation">
            <div className="toolbar-toggle-button">
                <DrawerBtn click={props.drawerClickHandler}/>
            </div>
            <div className="toolbar_logo"><a href="/"><img className="toolbar_img" src={logo}></img>Watermelon</a></div>
            <div className="spacer"/>
            <div className="toolbar_items">
                <ul>
                    <li><a href="/">Products</a></li>
                    <li><a href="/">Users</a></li>
                </ul>
            </div>
        </nav>
    </header>
);

export default toolbar